class h {
  /**
   * Get an item from chrome.storage
   */
  static async get(e, r) {
    var t;
    if (typeof chrome < "u" && ((t = chrome == null ? void 0 : chrome.storage) != null && t.sync))
      try {
        const n = await chrome.storage.sync.get([e]);
        if (n[e] !== void 0)
          return n[e];
      } catch (n) {
        console.warn(`[StorageEngine] Failed to read "${e}" from chrome.storage.sync:`, n);
      }
    else if (typeof localStorage < "u")
      try {
        const n = localStorage.getItem(`varia_ext_${e}`);
        if (n !== null)
          return JSON.parse(n);
      } catch (n) {
        console.warn(`[StorageEngine] Failed to read "${e}" from localStorage:`, n);
      }
    return r;
  }
  /**
   * Set an item in chrome.storage
   */
  static async set(e, r) {
    var t;
    if (typeof chrome < "u" && ((t = chrome == null ? void 0 : chrome.storage) != null && t.sync))
      try {
        await chrome.storage.sync.set({ [e]: r });
        return;
      } catch (n) {
        console.warn(`[StorageEngine] Failed to save "${e}" to chrome.storage.sync:`, n);
      }
    if (typeof localStorage < "u")
      try {
        localStorage.setItem(`varia_ext_${e}`, JSON.stringify(r));
      } catch (n) {
        console.warn(`[StorageEngine] Failed to save "${e}" to localStorage:`, n);
      }
  }
  /**
   * Subscribe to changes for a specific storage key
   */
  static subscribe(e, r) {
    var t;
    if (typeof chrome < "u" && ((t = chrome == null ? void 0 : chrome.storage) != null && t.onChanged)) {
      const n = (s, a) => {
        a === "sync" && s[e] && r(s[e].newValue, s[e].oldValue);
      };
      return chrome.storage.onChanged.addListener(n), () => chrome.storage.onChanged.removeListener(n);
    }
    if (typeof window < "u") {
      const n = (s) => {
        if (s.key === `varia_ext_${e}` && s.newValue !== null)
          try {
            r(
              JSON.parse(s.newValue),
              s.oldValue ? JSON.parse(s.oldValue) : void 0
            );
          } catch {
          }
      };
      return window.addEventListener("storage", n), () => window.removeEventListener("storage", n);
    }
    return () => {
    };
  }
}
const b = [
  {
    id: "x",
    name: "X (Twitter)",
    matchDomains: ["x.com", "twitter.com"],
    engines: [
      "https://fixupx.com",
      "https://fxtwitter.com",
      "https://cunnyx.com",
      "https://vxtwitter.com",
      "https://twittpr.com"
    ],
    selectedEngine: "https://fixupx.com",
    enabled: !0
  },
  {
    id: "reddit",
    name: "Reddit",
    matchDomains: ["reddit.com", "old.reddit.com"],
    engines: ["https://rxddit.com", "https://vxreddit.com"],
    selectedEngine: "https://rxddit.com",
    enabled: !0
  },
  {
    id: "instagram",
    name: "Instagram",
    matchDomains: ["instagram.com", "instagr.am"],
    engines: ["https://vxinstagram.com", "https://ddinstagram.com"],
    selectedEngine: "https://vxinstagram.com",
    enabled: !0
  },
  {
    id: "tiktok",
    name: "TikTok",
    matchDomains: ["tiktok.com", "vm.tiktok.com"],
    engines: ["https://tnktok.com", "https://tfxktok.com", "https://vxtiktok.com"],
    selectedEngine: "https://tnktok.com",
    enabled: !0
  },
  {
    id: "bluesky",
    name: "Bluesky",
    matchDomains: ["bsky.app"],
    engines: ["https://fxbsky.app"],
    selectedEngine: "https://fxbsky.app",
    enabled: !0
  },
  {
    id: "youtube",
    name: "YouTube",
    matchDomains: ["youtube.com", "youtu.be", "music.youtube.com", "m.youtube.com"],
    engines: ["https://youtu.be", "https://www.youtube.com", "https://music.youtube.com"],
    selectedEngine: "https://youtu.be",
    enabled: !0
  },
  {
    id: "threads",
    name: "Threads",
    matchDomains: ["threads.net"],
    engines: ["https://vxthreads.net", "https://fixthreads.net"],
    selectedEngine: "https://vxthreads.net",
    enabled: !0
  },
  {
    id: "pixiv",
    name: "Pixiv",
    matchDomains: ["pixiv.net"],
    engines: ["https://phixiv.net"],
    selectedEngine: "https://phixiv.net",
    enabled: !0
  }
], l = {
  enabled: !0,
  xEngine: "https://fixupx.com",
  stripTrackingParams: !0,
  showToast: !0,
  showInShareMenu: !0,
  autoConvertClipboard: !1,
  platforms: b
}, p = "varia_link_converter_config", E = /* @__PURE__ */ new Set([
  "s",
  "t",
  // will be preserved conditionally if numeric timestamp
  "ref_src",
  "ref_url",
  "twclid",
  "fbclid",
  "igshid",
  "utm_source",
  "utm_medium",
  "utm_campaign",
  "utm_term",
  "utm_content",
  "feature",
  "si",
  "cxt",
  "list",
  "index",
  "pp",
  "ab_channel",
  "start_radio",
  "themeRefresh",
  "embeds_referring_euri",
  "embeds_referring_origin",
  "source_ve_path"
]), _ = /^(https?:\/\/)?(www\.|m\.|music\.)?(youtube\.com\/(watch\?v=|shorts\/|embed\/|v\/)|youtu\.be\/)([a-zA-Z0-9_-]{11})/i;
function $(o) {
  const e = o.trim().match(_);
  if (e && e[5])
    return e[5];
  try {
    const t = new URL(o.startsWith("http") ? o : `https://${o}`).searchParams.get("v");
    if (t && t.length === 11) return t;
  } catch {
  }
  return null;
}
function S(o, e, r) {
  const t = d(e), n = r ? `?t=${r}` : "";
  return t === "youtu.be" ? `https://youtu.be/${o}${n}` : t.includes("music.youtube.com") ? `https://music.youtube.com/watch?v=${o}${n}` : `https://www.youtube.com/watch?v=${o}${n}`;
}
function g(o) {
  const e = [];
  o.forEach((r, t) => {
    (E.has(t.toLowerCase()) || t.toLowerCase().startsWith("utm_")) && e.push(t);
  }), e.forEach((r) => o.delete(r));
}
function d(o) {
  try {
    return new URL(o.startsWith("http") ? o : `https://${o}`).hostname;
  } catch {
    return o.replace(/^https?:\/\//, "").replace(/\/.*$/, "");
  }
}
function f(o, e) {
  const r = o.trim();
  if (!r)
    return { original: o, converted: o, matched: !1 };
  try {
    const t = new URL(r.startsWith("http") ? r : `https://${r}`), n = t.hostname.replace(/^www\./, "").toLowerCase();
    if (n === "x.com" || n === "twitter.com" || n.endsWith(".x.com") || n.endsWith(".twitter.com")) {
      e.stripTrackingParams && g(t.searchParams);
      const a = d(e.xEngine || "https://fixupx.com");
      t.hostname = a;
      const c = t.searchParams.toString(), i = `${t.protocol}//${t.hostname}${t.pathname}${c ? `?${c}` : ""}${t.hash}`;
      return {
        original: o,
        converted: i,
        matched: !0,
        platform: "X (Twitter)",
        engine: a
      };
    }
    for (const a of e.platforms) {
      if (!a.enabled) continue;
      if (a.matchDomains.some((i) => {
        const m = i.replace(/^www\./, "").toLowerCase();
        return n === m || n.endsWith(`.${m}`);
      })) {
        if (a.id === "youtube") {
          const u = $(r);
          if (u) {
            const x = t.searchParams.get("t"), v = S(u, a.selectedEngine, x), y = d(a.selectedEngine);
            return {
              original: o,
              converted: v,
              matched: !0,
              platform: "YouTube",
              engine: y
            };
          }
        }
        e.stripTrackingParams && g(t.searchParams);
        const i = d(a.selectedEngine);
        t.hostname = i;
        const m = t.searchParams.toString(), w = `${t.protocol}//${t.hostname}${t.pathname}${m ? `?${m}` : ""}${t.hash}`;
        return {
          original: o,
          converted: w,
          matched: !0,
          platform: a.name,
          engine: i
        };
      }
    }
  } catch {
  }
  return { original: o, converted: o, matched: !1 };
}
function T() {
  typeof chrome < "u" && (chrome != null && chrome.contextMenus) && (chrome.runtime.onInstalled.addListener(() => {
    chrome.contextMenus.create({
      id: "varia-copy-embed-link",
      title: "Copy as Embed Link",
      contexts: ["link", "page"]
    });
  }), chrome.contextMenus.onClicked.addListener(async (o, e) => {
    var r, t;
    if (o.menuItemId === "varia-copy-embed-link" && (e != null && e.id)) {
      const n = o.linkUrl || o.pageUrl;
      if (!n) return;
      const s = await h.get(
        p,
        l
      ), a = f(n, s);
      (t = (r = chrome.scripting) == null ? void 0 : r.executeScript) == null || t.call(r, {
        target: { tabId: e.id },
        func: (c) => {
          navigator.clipboard.writeText(c);
        },
        args: [a.converted]
      });
    }
  })), typeof chrome < "u" && (chrome != null && chrome.commands) && chrome.commands.onCommand.addListener(async (o) => {
    var e, r;
    if (o === "convert-active-tab") {
      const [t] = await chrome.tabs.query({ active: !0, currentWindow: !0 });
      if (t != null && t.id && (t != null && t.url)) {
        const n = await h.get(
          p,
          l
        ), s = f(t.url, n);
        (r = (e = chrome.scripting) == null ? void 0 : e.executeScript) == null || r.call(e, {
          target: { tabId: t.id },
          func: (a) => {
            navigator.clipboard.writeText(a);
          },
          args: [s.converted]
        });
      }
    }
  });
}
T();
console.log("[Varia Extension] Background Service Worker Initialized.");
